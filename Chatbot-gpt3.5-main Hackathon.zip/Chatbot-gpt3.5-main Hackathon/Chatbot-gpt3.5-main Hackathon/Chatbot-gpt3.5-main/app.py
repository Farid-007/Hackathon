from flask import Flask, jsonify, render_template, request
import openai

# Load OpenAI API key securely from environment variables or a secure config file
import os
from dotenv import load_dotenv

load_dotenv()
openai.api_key = ('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')

# Default response if the model fails to provide an answer
default_response = "This information is not available at the moment. For more queries, please contact our executive."

# Initialize the Flask app
app = Flask(__name__)

# Function to query GPT-3
def ask_gpt3(prompt):
    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "You're an AI assistant who answers user questions from the dataset."},
                {"role": "user", "content": prompt}
            ],
        )
        answer = response.choices[0].message['content'].strip()
        return answer
    except Exception as e:
        print(f"Error: {e}")
        return default_response

# Route to render the main HTML page
@app.route("/")
def index():
    return render_template("index.html")

# Route to handle user queries
@app.route("/ask", methods=['POST'])
def ask():
    user_input = request.form['user_input']
    response = ask_gpt3(user_input)
    return jsonify({"response": response})

# Run the Flask app
if __name__ == "__main__":
    app.run(debug=True)
